from django.urls import path

app_name = 'users'

urlpatterns = []